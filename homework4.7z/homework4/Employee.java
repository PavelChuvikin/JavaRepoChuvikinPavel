public class Employee {
    String name;
    String position;
    String phoneNumber;
    int salary;
    int age;
    static int id = 0;


    public Employee(String _name, String _position, String _phoneNumber, int _salary , int _age) {
        this.name =_name;
        position = _position;
        phoneNumber = _phoneNumber;
        salary = _salary;
        age = _age;
        id++;
    }
    public void printName(){
        System.out.println("ФИО: " + name);
    }
    public void printPosition(){
        System.out.println("Должность: " + position);
    }
    public void printPhoneNumber() {
        System.out.println("номер телефона: " + phoneNumber);
    }
    public void printSalary(){
        System.out.println("зарплата: " + salary);
    }
    public void printAge(){System.out.println("возраст: " + age);}
    //печать всей информации о работнике одним методом:
    public void printInfo(){
        System.out.println("Имя: " + name);
        System.out.println("Должность: " + position);
        System.out.println("номер телефона: " + phoneNumber);
        System.out.println("зарплата: " + salary);
        System.out.println("возраст: " + age);
        System.out.println("");
    }
}

