public class Test {
    public static void main(String[] args) {
        // создаем нового сотрудника employee1
        Employee employee1 = new Employee("Иванов Иван Иванович", "инженер", "+79152222222", 25000, 25);
        // методы выводящие в консоль ФИО, должность и т.д.
        employee1.printName();
        employee1.printPosition();
        employee1.printPhoneNumber();
        employee1.printSalary();
        employee1.printAge();
         // создаем массив сотрудников employeeArr
        Employee[] employeeArr = new Employee[5];
        employeeArr[0] = new Employee("Иванов Иван Иванович", "инженер", "+79152222221", 35000, 20);
        employeeArr[1] = new Employee("Сергеев Сергей Сергеевич", "оператор", "+79152222223", 45000, 34);
        employeeArr[2] = new Employee("Петров Петр Петрович", "шофер", "+79152222224", 55000, 35);
        employeeArr[3] = new Employee("Васильев Василий Васильевич", "токарь", "+79152222225", 65000,  36);
        employeeArr[4] = new Employee("Викторов Виктор Викторович", "кассир", "+79152222226", 75000, 20);
        System.out.println("");
        // запускаем метод проверки возраста
        employeeOlder35(employeeArr);
        // запускаем метод увеличения зарплаты
        salaryUpemployeeOlder35(employeeArr);
        // проверяем зарплату
         employeeArr[3].printSalary();
        //проверяем id (должно быть 6)
        System.out.println(Employee.id);
    }
    //метод проверки возраста
public static void  employeeOlder35(Employee[] arr) {
    boolean isemployeeOlder35 = true;
    System.out.println("Список сотрудников старше 35 лет:");
    System.out.println("");
    for (int i = 0; i < arr.length; i++){
        if (arr[i].age > 35) {
            arr[i].printInfo();
            isemployeeOlder35 = false;
        }
     }
       if (isemployeeOlder35 == true)
       System.out.println("Нет сотрудников старше 35 лет");
    }
    //метод проверки возраста
    public static void  salaryUpemployeeOlder35(Employee[] arr) {
        for (int i = 0; i < arr.length; i++){
            if (arr[i].age > 35) {
                arr[i].salary = arr[i].salary + 10000;
            }
        }
    }
   }
